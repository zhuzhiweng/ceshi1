#ifndef __TERMINAL_TEST_H
#define __TERMINAL_TEST_H
#include "sys.h" 
#include "stdio.h"
#include <string.h>



void TerminalTestProcess(void);
void CAN1test(CanRxMessage *pMsg);
uint8_t getTermianlState(void);

#endif



