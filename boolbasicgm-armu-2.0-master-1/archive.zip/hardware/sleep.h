#ifndef _SLEEP_H
#define _SLEEP_H
#include "sys.h" 
#include "stdio.h"
#include <string.h>
//#include "stm32f10x_rtc.h"
#include "n32g45x_bkp.h"
#include "n32g45x_pwr.h"

void sleep_s(uint8_t time_s);




#endif
