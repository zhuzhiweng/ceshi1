

#ifndef UTILS_H_
#define UTILS_H_


#include "cmsis_os.h"


extern uint8_t IsAscii(uint8_t ascii);

#endif 


